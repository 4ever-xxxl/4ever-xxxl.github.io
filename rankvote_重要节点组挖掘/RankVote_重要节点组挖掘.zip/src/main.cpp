#include <algorithm>
#include <ctime>
#include <iostream>
#include <numeric>
#include <queue>
#include <random>
#include <vector>
typedef long long ll;
using namespace std;
vector<int> Du, Vote;
vector<vector<int> > G;

void SelectByDu(int num);
void SelectByVote(int num);
bool cmp(int x, int y);
double Rand();
int TestSIR(vector<int> InitNode);

double f;
int n, m, u, v;
int num;              /* 选出的初始传播结点数目 */
double pjlunci = 500; /* 求平均值的轮数 */
vector<int> cntDu, cntVote;
double meanDu, meanVote, varianceDu, varianceVote;
double averageK, averageK2;
double SIRbeta, SIRalpha;

struct votenode {
  double score = 0, value = 1;
};

int main(int argc, char *argv[]) {
  srand(time(NULL));
  num = atoi(argv[2]);
  // SIRalpha = atof(argv[3]);
  SIRbeta = atof(argv[3]);
  freopen(argv[1], "r", stdin);
  freopen("data\\result.out", "w", stdout);
  cin >> n >> m;
  cout << "[+] vertices : " << n << " edges : " << m << endl;
  cout << "[+] the num of selected is " << num << endl;

  G.resize(n);
  for (int i = 0; i < m; i++) {
    cin >> u >> v;
    G[u].push_back(v), G[v].push_back(u);
  }
  averageK = 2.0 * m / n;
  f = 1.0 / averageK;

  SelectByDu(num);
  SelectByVote(num);

  for (auto &i : G) averageK2 += pow(i.size(), 2) / (double)n;

  // SIRbeta = SIRalpha * (averageK / averageK2);

  cout << "averageK = " << averageK << " averageK2 =" << averageK2 << "\n"
       << endl;
  cout << "SIRbeta = " << SIRbeta << "\n" << endl;

  for (int i = 0; i < pjlunci; i++) {
    cntDu.push_back(TestSIR(Du)), cntVote.push_back(TestSIR(Vote));
  }
  meanDu = accumulate(cntDu.begin(), cntDu.end(), 0.0) / pjlunci;
  meanVote = accumulate(cntVote.begin(), cntVote.end(), 0.0) / pjlunci;

  for (int i = 0; i < pjlunci; i++) {
    varianceDu += pow(cntDu[i] - meanDu, 2) / n;
    varianceVote += pow(cntVote[i] - meanVote, 2) / n;
  }

  cout << "[+] the mean of Du: " << meanDu
       << "    the variance of Du: " << varianceDu << endl;
  cout << "[+] the mean of Vote: " << meanVote
       << "    the variance of Vote: " << varianceVote << endl;
  cout << "rate : " << (meanVote - meanDu) / meanDu * 100 << " %" << endl;
  return 0;
}

bool cmp(int x, int y) { return G[x].size() > G[y].size(); }
double Rand() { return (double)rand() / RAND_MAX; }

// 以度为顺序选出前 num 大的节点
void SelectByDu(int num) {
  clock_t start, finish;
  start = clock();
  vector<int> a(n);
  for (int i = 0; i < n; i++) a[i] = i;
  nth_element(a.begin(), a.begin() + num, a.end(), cmp);
  cout << "[+] Select by degree of vertex" << endl;
  for (int i = 0; i < num; i++) Du.push_back(a[i]);
  sort(Du.begin(), Du.end(), cmp);
  // for (int i = 0; i < num; i++) {
  //   cout << Du[i] << " ";
  // }

  finish = clock();
  cout << endl
       << "[-] the time cost is:" << double(finish - start) / CLOCKS_PER_SEC
       << endl
       << endl;
}

void SelectByVote(int num) {
  clock_t start, finish;
  start = clock();
  vector<votenode> S(n);
  vector<int> vis(n);
  for (int i = 0; i < n; i++) {
    S[i].score = G[i].size(), S[i].value = (double)1;
  }
  while (num--) {
    double maxScore = -1;
    int p = -1;
    for (int i = 0; i < n; i++) {
      if (S[i].score > maxScore) {
        maxScore = S[i].score;
        p = i;
      }
    }

    if (maxScore == 0) {
      for (int i = 0; i < n; i++) {
        if (!vis[i]) {
          p = i;
          break;
        }
      }
    }
    vis[p] = 1;
    for (int i = 0; i < (int)G[p].size(); i++) {
      u = G[p][i];
      S[u].score -= S[p].value;
      double deltaval = S[u].value - max(S[u].value - f, (double)0);
      S[u].value = max(S[u].value - f, (double)0);
      for (int j = 0; j < (int)G[u].size(); j++) {
        v = G[u][j];
        S[v].score = max(S[v].score - deltaval, (double)0);
      }
    }
    S[p].score = S[p].value = 0;
    Vote.push_back(p);
  }

  cout << "[+] Select by vote of vertex" << endl;
  // for (int i = 0; i < (int)Vote.size(); i++) {
  //   cout << Vote[i] << " ";
  // }
  finish = clock();
  cout << endl
       << "[-] the time cost is:" << double(finish - start) / CLOCKS_PER_SEC
       << endl
       << endl;
}

int TestSIR(vector<int> InitNode) {
  vector<int> T(n, 0);
  queue<int> infected;
  for (auto &i : InitNode) {
    T[i] = 1;
    infected.push(i);
  }
  int infectedNum = InitNode.size(), infectCount = 0;
  while (!infected.empty()) {
    u = infected.front();
    infected.pop();
    T[u] = -1;
    for (int j = 0; j < (int)G[u].size(); j++) {
      v = G[u][j];
      if (T[v] == 0 && Rand() <= SIRbeta) {
        T[v] = 1;
        infected.push(v);
        infectedNum++;
      }
    }
    infectCount++;
  }
  return infectCount;
}